<script src="../../public/vendors/perfect-scrollbar/perfect-scrollbar.min.js"></script>
<script src="../../public/js/bootstrap.bundle.min.js"></script>

<script src="../../public/vendors/jquery/jquery.min.js"></script>
<script src="../../public/vendors/jquery-datatables/jquery.dataTables.min.js"></script>
<script src="../../public/vendors/jquery-datatables/custom.jquery.dataTables.bootstrap5.min.js"></script>
<script src="../../public/vendors/fontawesome/js/all.min.js"></script>
<script src="../../public/vendors/summernote/summernote-lite.min.js"></script>
<script src="../../public/vendors/sweetalert2/sweetalert2.js"></script>
<script src="../../public/vendors/toastify/toastify.js"></script>


<script src="../../public/vendors/Buttons/js/dataTables.buttons.js"></script>
<script src="../../public/vendors/JSZip-2.5.0/jszip.js"></script>
<script src="../../public/vendors/Buttons/js/buttons.html5.js"></script>


<script src="../../public/js/lib/fancybox/jquery.fancybox.pack.js"></script>
<script src="../../public/js/pages/horizontal-layout.js"></script>
<script src="../../public/js/lib/select2/select2.full.min.js"></script>
<script src="../../public/js/summernote-ES.js"></script>
<script src="../../public/js/mazer.js"></script>

